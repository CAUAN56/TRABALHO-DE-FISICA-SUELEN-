const tamanho = 5;
const casasEvento = [3, 7, 12, 18, 22];
const tabuleiro = document.getElementById("tabuleiro");
const mensagem = document.getElementById("mensagem");
const perguntaBox = document.getElementById("perguntaBox");
const perguntaTexto = document.getElementById("perguntaTexto");
let jogador1 = { nome: "Jogador 1", simbolo: "🔴", posicao: 0 };
let jogador2 = { nome: "Jogador 2", simbolo: "🔵", posicao: 0 };
let jogadorAtual = jogador1;

let perguntas = [
    { texto: "A eletricidade pode ser gerada por fontes renováveis como o vento e o sol.", resposta: true },
    { texto: "A corrente contínua (CC) muda de direção constantemente.", resposta: false },
    { texto: "Os elétrons são as partículas que carregam a corrente elétrica.", resposta: true },
    { texto: "A voltagem é medida em amperes.", resposta: false },
    { texto: "Materiais como cobre e alumínio são bons condutores elétricos.", resposta: true },
    { texto: "A resistência elétrica é medida em ohms.", resposta: true },
    { texto: "A água pura é um excelente condutor de eletricidade.", resposta: false },
    { texto: "Pilhas e baterias fornecem corrente contínua (CC).", resposta: true },
    { texto: "A corrente alternada (CA) é usada na maioria das residências.", resposta: true },
    { texto: "Fios desencapados são completamente seguros.", resposta: false },
    { texto: "Interruptores controlam o fluxo de corrente elétrica em um circuito.", resposta: true },
    { texto: "Um curto-circuito pode causar incêndios.", resposta: true },
    { texto: "A eletricidade não tem nenhuma relação com o magnetismo.", resposta: false },
    { texto: "A potência elétrica é medida em watts.", resposta: true },
    { texto: "A eletricidade se move mais lentamente em fios mais finos.", resposta: true },
    { texto: "Condutores têm alta resistência elétrica.", resposta: false },
    { texto: "Isolantes como borracha e plástico evitam o fluxo de corrente elétrica.", resposta: true },
    { texto: "A lei de Ohm relaciona tensão, corrente e resistência.", resposta: true },
    { texto: "Quanto maior a resistência, maior a corrente elétrica.", resposta: false },
    { texto: "Lâmpadas incandescentes são mais eficientes que lâmpadas LED.", resposta: false },
    { texto: "A eletricidade pode ser armazenada em capacitores.", resposta: true },
    { texto: "Transformadores alteram a tensão da corrente elétrica.", resposta: true },
    { texto: "Os circuitos em paralelo compartilham a mesma corrente.", resposta: false },
    { texto: "A corrente elétrica flui do polo negativo para o positivo.", resposta: true },
    { texto: "Um multímetro é usado para medir grandezas elétricas.", resposta: true },
    { texto: "As usinas nucleares não produzem eletricidade.", resposta: false },
    { texto: "A energia elétrica pode ser convertida em calor e luz.", resposta: true },
    { texto: "Tomadas de três pinos aumentam a segurança elétrica.", resposta: true },
    { texto: "Eletrodomésticos não utilizam energia elétrica.", resposta: false },
    { texto: "Fusíveis protegem os circuitos contra sobrecarga.", resposta: true }
];


function criarTabuleiro() {
    tabuleiro.innerHTML = "";
    for (let i = 0; i < tamanho * tamanho; i++) {
        let casa = document.createElement("div");
        casa.classList.add("casa");

        let simbolos = "";
        if (i === jogador1.posicao) simbolos += `<span class="peao jogador1">${jogador1.simbolo}</span>`;
        if (i === jogador2.posicao) simbolos += `<span class="peao jogador2">${jogador2.simbolo}</span>`;

        casa.innerHTML = simbolos;
        if (casasEvento.includes(i)) casa.classList.add("evento");
        tabuleiro.appendChild(casa);
    }
}

function rolarDado() {
    if (perguntaBox.style.display === "block") return;

    const dadoVisual = document.getElementById("dadoVisual");
    dadoVisual.classList.add("animando");

    setTimeout(() => {
        dadoVisual.classList.remove("animando");
        let dado = Math.floor(Math.random() * 6) + 1;
        dadoVisual.textContent = ["⚀","⚁","⚂","⚃","⚄","⚅"][dado - 1];
        mensagem.innerHTML = `🎲 ${jogadorAtual.nome} rolou: ${dado}`;
        sortearPergunta(dado);
    }, 600);
}

function sortearPergunta(dado) {
    let pergunta = perguntas[Math.floor(Math.random() * perguntas.length)];
    perguntaBox.style.display = "block";
    perguntaTexto.textContent = pergunta.texto;
    perguntaAtual = pergunta;
    movimentoDado = dado;
}

function responder(resposta) {
    perguntaBox.style.display = "none";
    if (resposta === perguntaAtual.resposta) {
        mensagem.innerHTML += `<br>✅ Resposta correta!`;
        jogadorAtual.posicao += movimentoDado;
        if (jogadorAtual.posicao >= tamanho * tamanho) {
            jogadorAtual.posicao = tamanho * tamanho - 1;
            mensagem.innerHTML += `<br>🎉 ${jogadorAtual.nome} venceu o jogo!`;
            criarTabuleiro();
            return;
        }
    } else {
        mensagem.innerHTML += `<br>❌ Resposta errada. Não avança.`;
    }
    jogadorAtual = (jogadorAtual === jogador1) ? jogador2 : jogador1;
    criarTabuleiro();
}

let perguntaAtual;
let movimentoDado;
criarTabuleiro();
